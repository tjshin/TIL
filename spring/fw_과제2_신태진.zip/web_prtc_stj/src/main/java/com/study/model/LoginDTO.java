package com.study.model;

import lombok.Data;

@Data
public class LoginDTO {
	
	private String id;
	
	private String password;
	
	private String userName;

}
