package com.study.prtc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebPrtcStjApplicationTests {

	@Test
	void contextLoads() {
	}

}
